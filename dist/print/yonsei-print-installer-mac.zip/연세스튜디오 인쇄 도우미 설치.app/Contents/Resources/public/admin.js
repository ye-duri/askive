// Operator-requested archive: preserve stored photos; hide receipts existing at this time.
const archivedThrough=Date.parse('2026-11-08T01:07:40Z');
import {receiptBook} from './receipt-numbers.mjs?v=20261108-daily';
const receipts=receiptBook(localStorage);
import {drawCalendar} from './calendar-layout.mjs?v=20261027-single';
const $=s=>document.getElementById(s);let printing=false,last='',selected=localStorage.getItem('yonsei-printer')||'';
const savedScale=Number(localStorage.getItem('yonsei-print-scale-fullbleed')||94);$('scale').value=Number.isInteger(savedScale)&&savedScale>=85&&savedScale<=100?savedScale:94;
$('scale').onchange=()=>{if($('scale').checkValidity()){localStorage.setItem('yonsei-print-scale-fullbleed',$('scale').value);last='';void refresh();}};
async function api(path,options={}){const r=await fetch(path,{...options,headers:{'Content-Type':'application/json','X-Yonsei-Admin':'1',...options.headers}});const d=await r.json();if(!r.ok)throw Error(d.error);return d;}
const rotations=new Map(),colors=new Map(),themes=new Map();
const labels={waiting:'인쇄 대기',sending:'프린터로 전송 중',submitted:'인쇄 대기열 전송 완료',uncertain:'인쇄 센터 확인 필요'};
async function refresh(){try{const d=await api('/admin/state');$('connection').value=d.connection;$('cloud-status').textContent=d.cloud?.status||'인쇄 도우미를 최신 버전으로 실행해 주세요.';
 const pairingKey=JSON.stringify(d.pairings||[]);
 if($('pairings').dataset.key!==pairingKey){$('pairings').dataset.key=pairingKey;$('pairings').replaceChildren();
 if(!d.pairings?.length)$('pairings').textContent='연결 요청을 기다리고 있어요.';
 for(const p of d.pairings||[]){const row=document.createElement('p'),label=document.createElement('strong');label.textContent=`${p.name} · 확인 숫자 ${p.code} `;row.append(label);
 for(const approve of [true,false]){const button=document.createElement('button');button.textContent=approve?'연결 승인':'거절';button.onclick=async()=>{button.disabled=true;try{await api(`/admin/pairings/${p.id}`,{method:'POST',body:JSON.stringify({approve})});await refresh();}catch(e){$('status').textContent=e.message;button.disabled=false;}};row.append(button);} $('pairings').append(row);}}

 const old=$('printer').value||selected;$('printer').replaceChildren(...d.printers.map(p=>new Option(p.name+(p.uri.startsWith('ippusb:')?' · USB':' · 네트워크'),p.name)));if(d.printers.some(p=>p.name===old))$('printer').value=old;
 d.jobs=d.jobs.filter(j=>new Date(j.createdAt).getTime()>archivedThrough);receipts.assign(d.jobs);const key=JSON.stringify(d.jobs);if(key!==last&&!printing&&!$('jobs').contains(document.activeElement)){last=key;$('jobs').replaceChildren();if(!d.jobs.length)$('jobs').textContent='iPad에서 전송한 사진이 여기에 표시됩니다.';
 for(const j of d.jobs){const article=document.createElement('article');article.className='job '+(Number(receipts.number(j.id))%2?'job-odd':'job-even');const img=new Image();img.src=`/admin/jobs/${j.id}/image`;img.alt='인쇄할 완성 사진';const section=document.createElement('section');const title=document.createElement('h2');title.textContent=labels[j.state];const date=document.createElement('p');date.textContent=new Date(j.createdAt).toLocaleString('ko-KR')+' · '+j.id.slice(0,8);const receipt=document.createElement('p');receipt.className='receipt-number '+(Number(receipts.number(j.id))%2?'receipt-odd':'receipt-even');receipt.textContent='접수 '+receipts.number(j.id);const heading=document.createElement('div');heading.className='receipt-heading';heading.append(receipt,date);section.append(heading,title);
 if(['waiting','submitted','uncertain'].includes(j.state)){const label=document.createElement('label');label.textContent='출력 매수';const count=document.createElement('input');count.type='number';count.min=1;count.max=10;count.value=1;label.append(count,document.createTextNode('장'));const print=document.createElement('button');print.className='print';print.textContent=j.state==='waiting'?'인쇄':'다시 인쇄';print.onclick=async()=>{if(printing)return;if(j.state==='uncertain'&&!confirm('이전 요청이 이미 출력됐을 수 있습니다. 인쇄 센터를 확인하셨다면 다시 인쇄해 주세요.'))return;printing=true;print.disabled=true;try{await api(`/admin/jobs/${j.id}/print`,{method:'POST',body:JSON.stringify({printer:$('printer').value,copies:Number(count.value),scale:Number($('scale').value),rotation:rotations.get(j.id)??j.rotation??(img.naturalWidth>img.naturalHeight?90:0),calendarColor:colors.get(j.id)||j.calendarColor||(j.printTheme==='siwol'?'#BF4022':j.printTheme==='want'?'#74151B':'#000000'),printTheme:themes.get(j.id)||j.printTheme||'default',qrUrl:j.qrUrl||'',reprint:j.state!=='waiting',expectedAttempt:j.attempt||0})});$('status').textContent='';}catch(e){$('status').textContent=e.message;}finally{printing=false;last='';document.activeElement?.blur();await refresh();}};const turn=document.createElement('button');turn.className='rotate';turn.type='button';const angle=()=>rotations.get(j.id)??j.rotation??(img.naturalWidth>img.naturalHeight?90:0);const preview=document.createElement('canvas');preview.className='rotated-preview';preview.hidden=true;img.after(preview);const updateRotation=()=>{turn.textContent=angle()===90?'원본 방향으로':'세로로 90° 회전';if(!img.naturalWidth)return;preview.hidden=false;img.hidden=true;drawCalendar(preview,img,Number($('scale').value),angle(),colors.get(j.id)||j.calendarColor||(j.printTheme==='siwol'?'#BF4022':j.printTheme==='want'?'#74151B':'#000000'),themes.get(j.id)||j.printTheme,j.qrUrl);turn.hidden=false;};img.onload=updateRotation;turn.onclick=()=>{rotations.set(j.id,angle()===90?0:90);updateRotation();};updateRotation();const palette=calendarPalette(colors.get(j.id)||j.calendarColor||(j.printTheme==='siwol'?'#BF4022':j.printTheme==='want'?'#74151B':'#000000'),color=>{colors.set(j.id,color);if(color==='#74151B')themes.set(j.id,'want');else if(color==='#BF4022')themes.set(j.id,'siwol');updateRotation();});section.append(label,palette,print,turn);section._preview=preview;}
 if(j.state!=='waiting'){const state=document.createElement('p');state.textContent=`최근 요청: ${j.copies}장 · ${j.scale||100}% · ${j.error||j.cupsJob||'전송 중'}`;section.append(state);}
 const del=document.createElement('button');del.className='delete';del.textContent='이 사진 삭제';del.disabled=j.state==='sending';del.onclick=async()=>{if(!confirm('Mac의 이 사진을 삭제할까요? 이미 보낸 인쇄 작업은 취소되지 않습니다.'))return;try{await api(`/admin/jobs/${j.id}`,{method:'DELETE'});last='';await refresh();}catch(e){$('status').textContent=e.message;}};section.append(del);const picture=document.createElement('div');picture.append(img);if(section._preview)picture.append(section._preview);article.append(picture,section);$('jobs').append(article);}}
 }catch(e){$('status').textContent='Mac 인쇄 도우미 연결을 확인해 주세요. '+e.message;}}
$('printer').onchange=()=>{selected=$('printer').value;localStorage.setItem('yonsei-printer',selected);};$('refresh').onclick=refresh;$('center').onclick=()=>alert('시스템 설정 → 프린터 및 스캐너 → CP1500 → 프린터 대기열에서 실제 작업 상태를 확인하세요.');$('copy').onclick=async()=>{try{await navigator.clipboard.writeText($('connection').value);$('copy').textContent='복사됨';}catch{$('connection').select();}};refresh();setInterval(refresh,2500);

$('cloud-connect').onclick=async()=>{const button=$('cloud-connect');button.disabled=true;try{await api('/admin/cloud',{method:'POST',body:JSON.stringify({code:$('cloud-code').value.trim()})});$('cloud-code').value='';await refresh();}catch(e){$('cloud-status').textContent=e.message;}finally{button.disabled=false;}};

function calendarPalette(value,onChange){
 const group=document.createElement('div');group.className='calendar-palette';group.hidden=true;group.setAttribute('role','group');group.setAttribute('aria-label','달력 색상');
 const labelText=document.createElement('span');labelText.className='calendar-label';labelText.textContent='달력 색상';group.append(labelText);
 const dropdown=document.createElement('details');dropdown.className='calendar-dropdown';group.append(dropdown);
 const summary=document.createElement('summary');summary.setAttribute('aria-label','달력 색상 선택');
 const current=document.createElement('span');current.className='color-swatch';current.setAttribute('aria-hidden','true');
 const currentName=document.createElement('span');summary.append(current,currentName);dropdown.append(summary);
 const choices=document.createElement('div');choices.className='calendar-colors';dropdown.append(choices);
 for(const [color,name] of [['#74151B','WANT'],['#BF4022','시월장'],['#794D32','가을 갈색'],['#166B9A','파랑'],['#38664B','초록'],['#765383','보라'],['#A44F66','로즈'],['#000000','검정']]){
  const button=document.createElement('button');button.type='button';button.className='calendar-color';button.dataset.color=color;button.setAttribute('aria-label',name);button.setAttribute('aria-pressed',String(color===value));
  const swatch=document.createElement('span');swatch.className='color-swatch';swatch.style.backgroundColor=color;swatch.setAttribute('aria-hidden','true');swatch.textContent='✓';
  const label=document.createElement('span');label.textContent=name;button.append(swatch,label);
  if(color===value){current.style.backgroundColor=color;currentName.textContent=name;}
  button.onclick=()=>{for(const item of choices.children)item.setAttribute('aria-pressed',String(item===button));current.style.backgroundColor=color;currentName.textContent=name;dropdown.open=false;summary.focus();onChange(color);};choices.append(button);
 }
 dropdown.onkeydown=event=>{if(event.key==='Escape'){dropdown.open=false;summary.focus();event.preventDefault();}};
 dropdown.ontoggle=()=>{if(dropdown.open)for(const other of document.querySelectorAll('.calendar-dropdown[open]'))if(other!==dropdown)other.open=false;};
 return group;
}
document.addEventListener('click',event=>{for(const dropdown of document.querySelectorAll('.calendar-dropdown[open]'))if(!dropdown.contains(event.target))dropdown.open=false;});
